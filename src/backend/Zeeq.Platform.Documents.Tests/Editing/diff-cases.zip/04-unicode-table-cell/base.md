# API status guide 🧭

This guide uses literal UTF-8 names.
The café heading uses a composed é.
The café alias uses a combining accent.

| State | Meaning | Retry |
| --- | --- | --- |
| ✅ Ready | Request can run | No |
| ⏳ Busy | Capacity is full | Immediately |
| ❌ Invalid | Fix the input | No |

Keep translated state names unchanged.
The 🇨🇦 label belongs to the tenant example.
Do not normalize Unicode while editing.
