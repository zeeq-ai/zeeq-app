---
keywords: logging, tracing, observability
---
# Logging conventions

Use structured log fields.
Keep event names stable.
Never log access tokens.

## Request scope

Attach a request ID.
Include the tenant ID after authorization.
Keep PII out of messages.
