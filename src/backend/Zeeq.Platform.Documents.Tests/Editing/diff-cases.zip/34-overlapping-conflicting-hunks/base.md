# Retry guidance

Context alpha.
Context beta.
Context gamma.
Old recommendation.
Context delta.
Context epsilon.
Context zeta.

Record the decision in the issue.
