# Shared boilerplate

## Team A
Context alpha.
Context beta.
Context gamma.
Old recommendation.
Context delta.
Context epsilon.
Context zeta.

## Team B
Context alpha.
Context beta.
Context gamma.
Old recommendation.
Context delta.
Context epsilon.
Context zeta.

End of guide.
