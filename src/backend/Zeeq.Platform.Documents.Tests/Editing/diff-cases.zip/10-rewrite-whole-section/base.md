# Review conventions

Use small reviewable changes.
Link the issue in the description.
Explain the customer-facing behavior.

## Legacy tests

Run all tests manually on Friday.
Paste screenshots into the ticket.
Ignore intermittent failures.

## Release checks

Verify the migration can roll back.
Check the staging health endpoint.
Keep the release owner available.
