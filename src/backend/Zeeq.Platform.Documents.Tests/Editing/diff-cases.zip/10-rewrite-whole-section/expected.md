# Review conventions

Use small reviewable changes.
Link the issue in the description.
Explain the customer-facing behavior.

## Required tests

Run focused tests before opening a PR.
Attach the test report.
Investigate intermittent failures.

## Release checks

Verify the migration can roll back.
Check the staging health endpoint.
Keep the release owner available.
