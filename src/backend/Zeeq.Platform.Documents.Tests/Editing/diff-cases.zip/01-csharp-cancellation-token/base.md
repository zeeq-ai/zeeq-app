# Cancellation in repositories

Pass the caller token to database operations.
The query must remain asynchronous.
Do not block on a Task.

```csharp
public async Task<User?> FindAsync(Guid id, CancellationToken token)
{
    var query = db.Users.Where(user => user.Id == id);
    return await query.SingleOrDefaultAsync();
}
```

Return null when the row is absent.
The handler maps null to a not-found response.
Log the request ID, not the token.
