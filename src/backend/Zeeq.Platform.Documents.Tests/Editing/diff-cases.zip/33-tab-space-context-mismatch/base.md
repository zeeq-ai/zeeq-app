# Shell indentation example

Use the literal indentation shown below.
This is a fenced sample.
Tabs are significant in copied snippets.

```bash
	prepare
	validate
	deploy
	report
	cleanup
```

Keep the final report in the ticket.
Use the staging environment first.
End of guidance.
