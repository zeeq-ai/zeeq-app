# Rate limit guide

Use exponential backoff.
Cap the delay at 30 seconds.
Add jitter to each retry.
Keep retries within the request timeout.
Record the attempt count.
Stop after three failures.