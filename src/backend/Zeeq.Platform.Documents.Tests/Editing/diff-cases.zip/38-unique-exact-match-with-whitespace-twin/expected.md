# Deployment recipes

## Recipe with two-space indentation
```bash
  prepare
  validate
  deploy
  report
  cleanup
```

## Recipe with tabs
```bash
	prepare
	validate
	deploy --wait
	report
	cleanup
```

Only the tabbed example is under review.
Keep both formatting styles in this test.
The matching policy must preserve intent.
