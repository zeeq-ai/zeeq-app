# Safe shell examples

Examples run in an isolated shell.
Never print credentials.
Use a fake hostname in docs.

```bash
curl --fail https://example.test/health
echo complete
```

Keep a copy of the command output.
Attach it to the deployment ticket.
Wait for the health check before continuing.
