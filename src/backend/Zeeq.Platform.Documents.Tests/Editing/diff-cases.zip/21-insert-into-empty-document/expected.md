# New team guide

Use one convention per section.
