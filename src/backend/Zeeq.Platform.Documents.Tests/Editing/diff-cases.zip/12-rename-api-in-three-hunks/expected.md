# TypeScript search client

The client is initialized once per page.
Use an explicit library name.
Pass a cancellation signal.
Keep the query supplied by the user.
```ts
const first = await client.searchDocuments({ library, query, signal });
```
Render results as a list.
Show the title and path.
Keep loading state visible.
Do not hide errors.
Store the last successful query.
Clear old results when the library changes.

## Refresh

Reuse the current request inputs.
Avoid starting two refreshes together.
```ts
const refreshed = await client.searchDocuments({ library, query, signal });
```
Replace the displayed result set.
Preserve keyboard focus.
Announce the result count.
Record request duration.
Keep telemetry free of document content.
Do not retry invalid queries.

## Background preview

Cancel when the row leaves the viewport.
Use the selected library.
```ts
const preview = await client.searchDocuments({ library, query, signal });
```
Render at most three matches.
Keep the full result accessible.
Use plain text for the excerpt.
Do not fetch private libraries implicitly.
