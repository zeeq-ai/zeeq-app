# Documenting patches

Keep a literal patch in the runbook.
The outer fence uses four backticks.
The inner example uses three backticks.

````markdown
## Example

```diff
--- a/README.md
+++ b/README.md
@@ -1 +1 @@
-Use the old client.
+Use the new client.
```

Copy the patch to a temporary file.
````

~~~bash
git apply --check /tmp/change.patch
~~~

Review the resulting document before saving.
