# Cache policies

## Request cache
Scope: one HTTP request.
### Example
```text
cache.set(key, value)
cache.get(key)
```
Discard values at request completion.
Never share user-specific results.

## Shared cache
Scope: all requests in the process.
### Example
```text
cache.set(key, value)
cache.get(key)
```
Expire values after five minutes.
Include tenant ID in every key.

Record cache misses in metrics.
