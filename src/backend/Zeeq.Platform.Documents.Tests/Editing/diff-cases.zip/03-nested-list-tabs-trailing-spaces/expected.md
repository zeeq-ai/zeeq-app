# Deployment checklist

- Prepare the release:
  - Check the migration status.  
  - Keep the release ID in the ticket.
  - Run the smoke check:

    ```bash
    make smoke ENV=staging
    ```
  - If it fails:
    - Stop the rollout.
    - Keep the previous revision active.

## Makefile convention

```make
smoke:
	curl --fail http://localhost/health
	@echo complete
```

Use a tab for a recipe command.
Do not expand tabs while editing this document.
